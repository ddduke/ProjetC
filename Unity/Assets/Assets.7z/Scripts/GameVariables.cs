﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameVariables : MonoBehaviour
{
    public float Maximum_Distance_Between_Cities = 2f;
}
