﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class Mapping_Cities : MonoBehaviour
{
    // Start is called before the first frame update
    public List<GameObject> CitiesTocheck = new List<GameObject>();
    public List<GameObject> CitiesCreated = new List<GameObject>();
    public int MaximumCitiesConnected = 2;
    public GameObject CityPrefab;
    public GameObject Moving_Lines;
    public GameObject[] objs;

    void Start()
    {

        CreatePointsOnMap();

        //get the map created into prevalidation function


        //At the end of the construction, we have to check multiple conditions in this function else we have to restart (creating points) and delete the previous ones
        int MaxTriesMap = 10;
        while (MapCondition() && MaxTriesMap > 0)
        {
            //Delete all cities created in the map (except start and end)
            foreach(GameObject City in CitiesCreated)
            {
                GameObject.Destroy(City);
            }
            objs = GameObject.FindGameObjectsWithTag("Route(Clone)");
            foreach (GameObject City in objs)
            {
                GameObject.Destroy(City);
            }
            CreatePointsOnMap();
            MaxTriesMap -= 1;
        }
        


        //we trace the routes inbetween connected cities
        objs = GameObject.FindGameObjectsWithTag("City");
        foreach (GameObject obj in objs)
        {
            List<GameObject> cities = new List<GameObject>(); 
            cities = obj.GetComponent<City_Variables>().CitiesConnected;
            foreach(GameObject objc in cities)
            {
                CreateRoute(obj, objc);
            }
        }

        //get the number of max cities connected (random 2 or 3) and check if the point has the maximum amount of cities connected

        //pop the first city in city list, create one instance in random x y positions but the x has to be positive (looking east) and y has to stay in a range to define (100 ?)

        //Check the connexions of the cities in map (get the connecting cities function here instead of starting game script) and check if it is over the max number (4)

        // if it is ok, put the City in CityToCheckList and loop to get the next city in citylist

        // if it is not ok, restart with next city in citylist







        //
    }


    void CreatePointsOnMap ()
    {
        float MCMaximum_Distance_Between_Cities = GetComponent<GameVariables>().Maximum_Distance_Between_Cities;
        CityPrefab = Resources.Load("Ville") as GameObject;
        GameObject StartCity = GameObject.Find("Bordeaux");
        GameObject EndCity = GameObject.Find("Nice");
        //Debug.Log("here is the cities found"+StartCity+ EndCity);


        //Get a citylist of the cities to create  and mix them in order to create random and a CityToCheckList with only start at the beginning
        var CitiesToCreate = new Queue<string>();

        CitiesToCreate.Enqueue("Marseille");
        CitiesToCreate.Enqueue("Beziers");
        CitiesToCreate.Enqueue("Nimes");
        CitiesToCreate.Enqueue("Biarritz");
        CitiesToCreate.Enqueue("Perpignan");
        CitiesToCreate.Enqueue("Aix");
        CitiesToCreate.Enqueue("Toulon");
        CitiesToCreate.Enqueue("SalonDeProvence");
        CitiesToCreate.Enqueue("Lyon");
        CitiesToCreate.Enqueue("Grenoble");

        CitiesTocheck.Add(StartCity);
        int MaxTries = 10;
        //pop one city (city start first) already created from CityToCheckList
        while (Map_in_construction(CitiesToCreate))
        {

            GameObject OriginCity = CitiesTocheck[0];
            Debug.Log("We're checking " + OriginCity);
            float MaximumRandom = MCMaximum_Distance_Between_Cities;
            Vector3 CityPosition = new Vector3(Random.Range(5, MaximumRandom), Random.Range(5, 12), 1);

            while (PointCondition(CityPosition) && MaxTries > 0)
            {
                CityPosition = new Vector3(Random.Range(5, MaximumRandom), Random.Range(5, 12), 1);
                MaxTries -= 1;
            }
            if (MaxTries == 0) Debug.Log("nb max de try atteint");
            GameObject CityCreated = Instantiate(CityPrefab, CityPosition, Quaternion.identity);
            CityCreated.name = CitiesToCreate.Dequeue();
            CityCreated.tag = "City";
            CitiesCreated.Add(CityCreated);
            CheckRoutes();
            Debug.Log("City " + CityCreated.name + " created at " + CityCreated.transform.position + "Origin City" + OriginCity.name + "with " + OriginCity.GetComponent<City_Variables>().CitiesConnected.Count + "Cities Connected");
            //Write the if condition for the city to check to be removed (3 or less cities connected)
            if (OriginCity.GetComponent<City_Variables>().CitiesConnected.Count > MaximumCitiesConnected) CitiesTocheck.RemoveAt(0);
            CitiesTocheck.Add(CityCreated);
        }
        //we check if the endcity has a minimum of 1 city connected
        if (EndCity.GetComponent<City_Variables>().CitiesConnected.Count == 0)
        {
            objs = GameObject.FindGameObjectsWithTag("City");
            //Debug.Log(GameObject.FindGameObjectsWithTag("City").Length);
            //we take a city from the list and compare it to all the other cities in the list
            GameObject LowestDistanceCity = StartCity;
            foreach (GameObject obj in objs)
            {
                if (obj != EndCity)
                { 
                    if (Vector3.Distance(EndCity.transform.position, obj.transform.position) < Vector3.Distance(EndCity.transform.position, LowestDistanceCity.transform.position))
                    {
                        LowestDistanceCity = obj;
                    }
                }
            }
            EndCity.GetComponent<City_Variables>().CitiesConnected.Add(LowestDistanceCity);
            LowestDistanceCity.GetComponent<City_Variables>().CitiesConnected.Add(EndCity);
        }
        //we check if the startcity has a minimum of 1 city connected
        if (StartCity.GetComponent<City_Variables>().CitiesConnected.Count == 0);
        {
            objs = GameObject.FindGameObjectsWithTag("City");
            //Debug.Log(GameObject.FindGameObjectsWithTag("City").Length);
            //we take a city from the list and compare it to all the other cities in the list
            GameObject LowestDistanceCity = EndCity;
            foreach (GameObject obj in objs)
            {
                if (obj != StartCity)
                {
                    if (Vector3.Distance(StartCity.transform.position, obj.transform.position) < Vector3.Distance(StartCity.transform.position, LowestDistanceCity.transform.position))
                    {
                        LowestDistanceCity = obj;
                    }
                }
            }
            StartCity.GetComponent<City_Variables>().CitiesConnected.Add(LowestDistanceCity);
            LowestDistanceCity.GetComponent<City_Variables>().CitiesConnected.Add(StartCity);
        }
        //We Check if a path exists between start and end and else create it
        if (!PathExist())
        { 
            List<GameObject> NewCitiesToCheck = new List<GameObject>();
            List<GameObject> CitiesChecked = new List<GameObject>();
            GameObject ActualCity = StartCity;
            GameObject EasternCity = StartCity;
            //we get all the gameobjects connected to start city
            NewCitiesToCheck.Add(ActualCity);
            while (NewCitiesToCheck.Count()>0)
            {

                ActualCity = NewCitiesToCheck[0];
                List<GameObject> TempList = new List<GameObject>();
                TempList = ActualCity.GetComponent<City_Variables>().CitiesConnected;
                foreach (GameObject City in TempList)
                {
                    if (!CitiesChecked.Contains(City)) NewCitiesToCheck.Add(City);

                    Debug.Log("proutCheck" +  City);

                }
                NewCitiesToCheck.Remove(ActualCity);
                CitiesChecked.Add(ActualCity);
                Debug.Log("proutActual" + ActualCity);
            }
            //we search the easternCity in gameobjects connected to startCity
            foreach (GameObject City in CitiesChecked)
            {
                Debug.Log("proutEasternCompare" + EasternCity + City);
                if (EasternCity.transform.position.x > City.transform.position.x) EasternCity = City;

            }
            Debug.Log("proutEastern" + EasternCity);
            objs = GameObject.FindGameObjectsWithTag("City");
            //we set the easterngame object with a connected city to the 1st city next to it
            GameObject LowestDistanceCity = EndCity;
            foreach (GameObject obj in objs)
            {
                if (EasternCity.transform.position.x > obj.transform.position.x)
                {
                    Debug.Log("prout" + obj);
                    if (Vector3.Distance(EasternCity.transform.position, obj.transform.position) < Vector3.Distance(EasternCity.transform.position, LowestDistanceCity.transform.position))
                    {
                        LowestDistanceCity = obj;
                    }
                }

            }
            EasternCity.GetComponent<City_Variables>().CitiesConnected.Add(LowestDistanceCity);
            LowestDistanceCity.GetComponent<City_Variables>().CitiesConnected.Add(EasternCity);
        }
        //we check if a city is alone and else create a route to this one
        objs = GameObject.FindGameObjectsWithTag("City");
        foreach (GameObject obj in objs)
        {
            if (obj.GetComponent<City_Variables>().CitiesConnected.Count()==0)
            {
                GameObject LowestDistanceCity = EndCity;
                foreach (GameObject objc in objs)
                {
                    if (obj!=objc && Vector3.Distance(obj.transform.position, objc.transform.position) < Vector3.Distance(obj.transform.position, LowestDistanceCity.transform.position))
                    {
                        LowestDistanceCity = obj;
                    }
                }
                obj.GetComponent<City_Variables>().CitiesConnected.Add(LowestDistanceCity);
                LowestDistanceCity.GetComponent<City_Variables>().CitiesConnected.Add(obj);
            }
        }
        

    }


    bool PathExist()
    {
        List<GameObject> NewCitiesToCheck = new List<GameObject>();
        List<GameObject> CitiesChecked = new List<GameObject>();
        GameObject StartCity = GameObject.Find("Bordeaux");
        GameObject EndCity = GameObject.Find("Nice");
        GameObject ActualCity = StartCity;
        NewCitiesToCheck.Add(StartCity);
        while (ActualCity != EndCity)
        {
            if (NewCitiesToCheck.Count() == 0) return false;
            ActualCity = NewCitiesToCheck[0];
            List<GameObject> TempList = new List<GameObject>(); 
            TempList = ActualCity.GetComponent<City_Variables>().CitiesConnected;
            foreach (GameObject City in TempList)
            {
                if (!CitiesChecked.Contains(City)) NewCitiesToCheck.Add(City);
            }
            NewCitiesToCheck.Remove(ActualCity);
            CitiesChecked.Add(ActualCity);
            
        }
        return true;
    }


    //Check if the finished map reach all conditions 
    bool MapCondition()
    {
        GameObject EndCity = GameObject.Find("Nice");
        if (EndCity.GetComponent<City_Variables>().CitiesConnected.Count == 0)
        {
            Debug.Log("probleme endcity trouvé");
            return true;
        }
        else
        {
            Debug.Log("Pas de probleme endcity");
            GameObject StartCity = GameObject.Find("Bordeaux");
            if (StartCity.GetComponent<City_Variables>().CitiesConnected.Count == 0)
            {
                Debug.Log("probleme startcity trouvé");
                return true;
            }
            else
            {
                Debug.Log("Pas de probleme startcity");
                return false;
            }
        }
        

    }

    //check if the point created randomly respond to all requirements

    public float MinimumDistanceBetweenCities = 1f;

    bool PointCondition(Vector3 CityPosition)
    {
        objs = GameObject.FindGameObjectsWithTag("City");
        foreach(GameObject obj in objs)
        {
            if (Vector3.Distance(CityPosition, obj.transform.position) < MinimumDistanceBetweenCities)
            {
                Debug.Log("point trop proche!" + CityPosition + obj.transform.position);
                return true;
            }
        }
        return false;
    }

    bool Map_in_construction (Queue<string> CitiesToCreate)
    {
        //Check if the EndCity has the maximum of cities connected or if there is no cities left to create
        if (CitiesToCreate.Count == 0) return false;
        else return true;
    }


    //Functions for Mapping Cities
    public Dictionary<GameObject, float> CityDistance = new Dictionary<GameObject, float>();

    // Start is called before the first frame update
    void CheckRoutes()
    {
        //Debug.Log("launching checkroutes");
        //we make a list with all cities existing in the scene
        objs = GameObject.FindGameObjectsWithTag("City");
        //Debug.Log(GameObject.FindGameObjectsWithTag("City").Length);
        //we take a city from the list and compare it to all the other cities in the list
        foreach (GameObject obj in objs)
        {
            obj.GetComponent<City_Variables>().CitiesConnected.Clear();
            foreach (GameObject objc in objs)// we get the city we want to compare from the list
            {
                objc.GetComponent<City_Variables>().CitiesConnected.Remove(obj);
                if (obj == objc) // if it is the same city, just pass 
                {
                    //Debug.Log("it is the same city!");

                }
                else // if it is a different city
                {
                    CityDistance.Add(objc, Vector3.Distance(objc.transform.position, obj.transform.position));
                }

            }
            Debug.Log("pour la ville" + obj);
            Debug.Log("voici les valeurs du dictionnaire avant traitement");
            foreach (KeyValuePair<GameObject, float> city in CityDistance.OrderBy(Key => Key.Value))
            {
                    Debug.Log("voici la valeur du dictionnaire" + city);
            }
            //Debug.Log("here is the connected cities for the city " + obj);
            int i = 0;
            foreach (KeyValuePair<GameObject, float> city in CityDistance.OrderBy(Key => Key.Value))
            {
                if (i <= MaximumCitiesConnected)
                {
                    Debug.Log("voici la valeur du dictionnaire en cours de traitement" + city);
                    //we set the both cities in the ConnectedCities List of each other
                    obj.GetComponent<City_Variables>().CitiesConnected.Add(city.Key);
                    city.Key.GetComponent<City_Variables>().CitiesConnected.Add(obj);
                    i += 1;
                }
                if (i > MaximumCitiesConnected) Debug.Log("ville " + city + "non connectée car trop de villes connectées ");
            }
                
            CityDistance.Clear();
            //remettre à jour les distances à chaque fois sinon on a des distances en fonction des premiers points créés...

        }

    }

    void CreateRoute(GameObject A, GameObject B)
    {
        Moving_Lines = Resources.Load("Route") as GameObject;
        // first we define the position in the middle of the 2 cities to create the prefab route here : aka MovingLinesPosition
        float Lerpratio = 0.5f;
        Vector3 MovingLinesPosition = Vector3.Lerp(A.transform.position, B.transform.position, Lerpratio);
        // then we define the rotation for the object to face both cities in order to create the route in the right direction
        Vector3 VectorToTarget = B.transform.position - A.transform.position;
        float angle = Mathf.Atan2(VectorToTarget.x, VectorToTarget.y) * Mathf.Rad2Deg;
        //Creation of the route object with position & rotation identified previously
        GameObject NewRoute = Instantiate(Moving_Lines, MovingLinesPosition, Quaternion.Euler(0, 0, -angle));
        // set the Y scale to the distance of the 2 cities to join them
        NewRoute.transform.localScale += new Vector3(0, Vector3.Distance(B.transform.position, A.transform.position), 0);
        // set the z position 1 higher than the cities to let the cities visible
        NewRoute.transform.localPosition += new Vector3(0, 0, 0.5f);

    }
}
