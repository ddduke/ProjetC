﻿using System.Collections;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;

public class moving : MonoBehaviour
{
    public GameObject city;
    public int movement_speed;
    public Vector2 city_position;
    public Vector2 player_position;

    // Start is called before the first frame update
    void Start()
    {
        Debug.Log("moving est lancé");
        //city_position = city.transform.position;

    }

    // Update is called once per frame
    void FixedUpdate()
    {
        player_position = transform.position;
        transform.position = Vector2.MoveTowards(transform.position, city_position, Time.deltaTime * movement_speed);
    }


}
