﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class moving_to_city : MonoBehaviour
{
    public GameObject player;

    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.Find("Player"); 
        if (player == null) Debug.Log("player not found");

    }
    // Update is called once per frame
    void FixedUpdate()
    {

    }

    void OnMouseDown()
    {
        //find a way to prevent the player to click when the animation is running (like a variable to check if the event did not finished and get automatically the player on the final position ?)
        Debug.Log("Pressed left click, launching movement");
        player.GetComponent<moving>().city_position = transform.position;
        Debug.Log(transform.position);
        player.GetComponent<moving>().enabled = !player.GetComponent<moving>().enabled;
    }
}
